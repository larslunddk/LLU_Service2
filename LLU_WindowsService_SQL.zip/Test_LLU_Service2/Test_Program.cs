﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LLU_Service2;

namespace Test_LLU_Service2
{
    class Test_Program
    {
        static void Main(string[] args)
        {
            LibrarySQL.TestSQLCall001(); 
        }
    }
}
